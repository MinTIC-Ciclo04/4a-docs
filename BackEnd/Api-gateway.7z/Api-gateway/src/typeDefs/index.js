const reservaYaBackTypeDefs = require('./reservaya_back_type_defs');
const bookingTypeDefs = require('./reserva_ya_mvn_td');

const typeDefs = [reservaYaBackTypeDefs,bookingTypeDefs];

module.exports = typeDefs;