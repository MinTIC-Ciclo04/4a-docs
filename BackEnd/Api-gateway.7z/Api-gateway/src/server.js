module.exports = {
       reservaya_back_api_url: 'https://reservaya-back.herokuapp.com/',
       bookingUrl: 'https://reserva-ya-mvn.herokuapp.com',
    };